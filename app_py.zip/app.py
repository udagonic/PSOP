import webbrowser
from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os
import threading

app = Flask(__name__, template_folder=r'C:\Users\yuusu\Desktop\授業記録 exe用\templates')


# スクリプトのディレクトリに移動
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# データベースの初期化
def init_db():
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    
    # データベースファイルが存在しない場合に新規作成
    if not os.path.exists(DB_PATH):
        print("データベースが見つかりません。新しいデータベースを作成します。")
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # 授業テーブル
    c.execute('''
        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT NOT NULL,
            class_date TEXT NOT NULL
        )
    ''')
    # 授業記録テーブル
    c.execute('''
        CREATE TABLE IF NOT EXISTS class_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            FOREIGN KEY (class_id) REFERENCES classes (id)
        )
    ''')
    conn.commit()
    conn.close()

# トップページ: 授業一覧
@app.route('/')
def index():
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT id, class_name, class_date FROM classes')
    classes = [{'id': row[0], 'class_name': row[1], 'class_date': row[2]} for row in c.fetchall()]
    conn.close()
    return render_template('class_list.html', classes=classes)

# 授業追加ページ
@app.route('/add', methods=['GET', 'POST'])
def add_class():
    if request.method == 'POST':
        class_name = request.form['class_name']
        class_date = request.form['class_date']
        DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('INSERT INTO classes (class_name, class_date) VALUES (?, ?)', (class_name, class_date))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('add_class.html')

# 授業詳細・記録管理ページ
@app.route('/class/<int:id>', methods=['GET', 'POST'])
def view_class(id):
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # 授業情報を取得
    c.execute('SELECT id, class_name, class_date FROM classes WHERE id = ?', (id,))
    class_data = c.fetchone()
    if not class_data:
        conn.close()
        return "授業が見つかりません", 404
    class_data = {'id': class_data[0], 'class_name': class_data[1], 'class_date': class_data[2]}

    # 授業記録を取得
    c.execute('SELECT id, date, description FROM class_records WHERE class_id = ?', (id,))
    records = [{'id': row[0], 'date': row[1], 'description': row[2]} for row in c.fetchall()]

    if request.method == 'POST':
        # 新しい記録を追加
        if 'add_record' in request.form:
            date = request.form['date']
            description = request.form['description']
            c.execute('INSERT INTO class_records (class_id, date, description) VALUES (?, ?, ?)', (id, date, description))
            conn.commit()
        # 記録を編集
        edit_record_id = request.form.get('edit_record_id')
        if edit_record_id:
            edit_record_id = int(edit_record_id)
            date = request.form[f'edit_date_{edit_record_id}']
            description = request.form[f'edit_description_{edit_record_id}']
            c.execute('UPDATE class_records SET date = ?, description = ? WHERE id = ?', (date, description, edit_record_id))
            conn.commit()
        conn.close()
        return redirect(url_for('view_class', id=id))

    conn.close()
    return render_template('view_class.html', class_data=class_data, records=records)

# 授業記録の削除機能
@app.route('/class/<int:class_id>/delete_record/<int:record_id>', methods=['POST'])
def delete_record(class_id, record_id):
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('DELETE FROM class_records WHERE id = ? AND class_id = ?', (record_id, class_id))
    conn.commit()
    conn.close()
    return redirect(url_for('view_class', id=class_id))

# 授業削除機能
@app.route('/class/<int:id>/delete', methods=['POST'])
def delete_class(id):
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('DELETE FROM class_records WHERE class_id = ?', (id,))
    c.execute('DELETE FROM classes WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

# 授業編集機能
@app.route('/class/<int:id>/edit', methods=['GET', 'POST'])
def edit_class(id):
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    if request.method == 'POST':
        class_name = request.form['class_name']
        class_date = request.form['class_date']
        c.execute('UPDATE classes SET class_name = ?, class_date = ? WHERE id = ?', (class_name, class_date, id))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    c.execute('SELECT id, class_name, class_date FROM classes WHERE id = ?', (id,))
    class_data = c.fetchone()
    conn.close()

    if not class_data:
        return "授業が見つかりません", 404

    return render_template('edit_class.html', class_data={'id': class_data[0], 'class_name': class_data[1], 'class_date': class_data[2]})

# 授業記録の印刷ページ
@app.route('/class/<int:id>/print')
def print_records(id):
    DB_PATH = os.path.join(os.getcwd(), 'e_karte.db')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # 授業情報を取得
    c.execute('SELECT id, class_name, class_date FROM classes WHERE id = ?', (id,))
    class_data = c.fetchone()
    if not class_data:
        conn.close()
        return "授業が見つかりません", 404
    class_data = {'id': class_data[0], 'class_name': class_data[1], 'class_date': class_data[2]}

    # 授業記録を取得
    c.execute('SELECT id, date, description FROM class_records WHERE class_id = ?', (id,))
    records = [{'id': row[0], 'date': row[1], 'description': row[2]} for row in c.fetchall()]
    conn.close()

    return render_template('print_records.html', class_data=class_data, records=records)

def open_browser():
    webbrowser.open('http://127.0.0.1:5000', new=2)

if __name__ == '__main__':
    init_db()
    # Create a thread to open the browser after the server starts
    threading.Thread(target=open_browser).start()
    app.run(debug=True, use_reloader=False)  # use_reloader=Falseで二重起動を防止
